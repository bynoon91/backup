package com.sehyunict.smartgeokit.batch.sgk.vo;

import java.util.Date;

public class SGKHistoryVo {

	private Integer queueSeq;	// 큐 식별 아이디
	private String jobId;			// 작업 식별 아이디
	private Integer stepSeq;		// 작업단계 식별 아이디
	private String jobData;		// 작업 파라미터
	private String targetServer;	// 실행서버
	private String result;			// 결과
	private Date startDate;		// 작업단계 시작시간
	private Date endDate;			// 작업단계 종료시간
	private Date regDate;			// 이력 등록시간

	public Integer getQueueSeq() {
		return queueSeq;
	}
	public void setQueueSeq( Integer queueSeq ) {
		this.queueSeq = queueSeq;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId( String jobId ) {
		this.jobId = jobId;
	}
	public Integer getStepSeq() {
		return stepSeq;
	}
	public void setStepSeq( Integer stepSeq ) {
		this.stepSeq = stepSeq;
	}
	public String getJobData() {
		return jobData;
	}
	public void setJobData( String jobData ) {
		this.jobData = jobData;
	}
	public String getTargetServer() {
		return targetServer;
	}
	public void setTargetServer(String targetServer) {
		this.targetServer = targetServer;
	}
	public String getResult() {
		return result;
	}
	public void setResult( String result ) {
		this.result = result;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate( Date startDate ) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate( Date endDate ) {
		this.endDate = endDate;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate( Date regDate ) {
		this.regDate = regDate;
	}

	@Override
	public String toString() {
		return "SGKHistoryVo [queueSeq=" + queueSeq + ", jobId=" + jobId + ", stepSeq=" + stepSeq + ", jobData="
				+ jobData + ", result=" + result + ", startDate=" + startDate + ", endDate=" + endDate + ", regDate="
				+ regDate + "]";
	}

}
