package com.sehyunict.smartgeokit.batch.sgk.service;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.sehyunict.smartgeokit.batch.exception.SgkJobException;
import com.sehyunict.smartgeokit.batch.sgk.dao.SGKExecuteDAO;
import com.sehyunict.smartgeokit.batch.sgk.execute.SGKExecute;
import com.sehyunict.smartgeokit.batch.sgk.util.SGKProperties;
import com.sehyunict.smartgeokit.batch.sgk.util.SGKUtil;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKExecuteVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKHistoryFailVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKHistoryVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKJobStepVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKJobVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKQueueVo;

@Service
public class SGKExecuteService {

	private static final Logger logger = LogManager.getLogger(SGKExecuteService.class);

	public static final String RESULT_SUCCESS = "SUCCESS";
	public static final String RESULT_FAIL = "FAIL";

	private Map<String, SGKJobVo>		jobVoMap;		// job 정보
	private Map<String, SGKJobStepVo>	stepVoMap;		// job step 정보
	private Map<String, SGKExecute>		jobObjectMap;	// 작업 기준정보

	private List<SGKExecuteVo> executeList;				// 실행목록
	private List<String> resultFiles;					// 결과파일목록

	@Autowired
	private SGKExecuteDAO executeDao;

	@Autowired
	private SGKProperties properties;

	@Autowired
	private ApplicationContext context;

	/**
	 * job 목록 조회 - 객체 생성될 때 최초 1회 실행
	 */
	@PostConstruct
	public void getJobs() {

		try {
			// TB_SGK_JOB 조회
			List<SGKJobVo> jobVoList = executeDao.selectJobList();
			this.jobObjectMap = new HashMap<String, SGKExecute>();
			this.jobVoMap = new HashMap<String, SGKJobVo>();
			for (SGKJobVo sgkJobVo : jobVoList) {
				SGKExecute jobObject = (SGKExecute) context.getBean(sgkJobVo.getJobId());
				this.jobObjectMap.put(sgkJobVo.getJobId(), jobObject);
				this.jobVoMap.put(sgkJobVo.getJobId(), sgkJobVo);
			}

			// TB_SGK_JOB_STEP 조회
			List<SGKJobStepVo> stepVoList = executeDao.selectStepList();
			this.stepVoMap = new HashMap<String, SGKJobStepVo>();
			for (SGKJobStepVo sgkStepVo : stepVoList) {
				this.stepVoMap.put(sgkStepVo.getJobId()+","+sgkStepVo.getStepSeq(), sgkStepVo);
			}
		} catch (Exception e) {
			logger.error("### getJobs ERROR!!!!!!!!");
			e.printStackTrace();
		}

	}

	// execute 목록 조회
	public void getExecutes() throws SgkJobException {

		try {
			// TB_SGK_JOB_EXECUTE 데이터 조회
			this.executeList = executeDao.selectExecuteList(SGKUtil.getConfig("TARGET_SERVER"));
		} catch (Exception e) {
			// ERR00-007 : execute 목록조회 오류
			throw new SgkJobException("ERR00-007", e);
		}
	}

	// 작업목록 실행
	public void run() throws SgkJobException {

		if(this.resultFiles.size() > 0){
			logger.debug("****************   [ SGK_EXECUTE ] - START -   ****************");
		}

		for (SGKExecuteVo executeVo : this.executeList) {

			for (String resultFileName : this.resultFiles) {

				SGKHistoryVo historyVo = SGKUtil.fileNameToHistroyVo( resultFileName );

				// jobs 폴더 밑의 결과가 있는 execute만 실행
				if (executeVo.getQueueSeq().intValue() == historyVo.getQueueSeq().intValue()) {
					String jobId = executeVo.getJobId();
					try {

						// HISTORY에 데이터(START_DATE) INSERT
						historyVo.setStartDate(new Date());
						historyVo.setRegDate(new Date());
						executeDao.insertHistory(historyVo);

						// 작업 수행
						this.jobObjectMap.get(jobId).execute(executeVo);

					} catch(SgkJobException jobE) {
						// 에러 발생 시 executeVo 내용 셋팅
						jobE.setExecuteVo(executeVo);
						throw jobE;
					} catch (Exception e) {
						SgkJobException jobE = new SgkJobException("ERR00-000", e);
						// 에러 발생 시 executeVo 내용 셋팅
						jobE.setExecuteVo(executeVo);
						throw jobE;
					}
				}
			}
		}

		if(this.resultFiles.size() > 0){
			logger.debug("****************   [ SGK_EXECUTE ] - END -   ****************");
		}
	}

	// 완료된 단계 이력 추가
	public void saveHistory() throws SgkJobException {
		String targetResultFileName = "";
		try {
			for (String resultFileName : this.resultFiles) {
				targetResultFileName = resultFileName;
				// STEP 별 이력 추가
				// "77#SUCCESS" => { queueSeq: 77, result: "SUCCESS" }
				SGKHistoryVo historyVo = SGKUtil.fileNameToHistroyVo( resultFileName );
				SGKExecuteVo executeVo = executeDao.selectExecuteByQueueSeq( historyVo.getQueueSeq() );

				// 진행중인 상태인 경우만 history를 update
				if( SGKUtil.isEmpty(executeVo)){
					// 만약 execute에 없는 경우에는 queue에서 삭제
					executeDao.lockQueueTable();
					executeDao.deleteQueue(historyVo.getQueueSeq());
					executeDao.unlockQueueTable();
					continue;
				}

				File resultFile = new File(SGKUtil.getConfig("FILE_JOBS_PATH") + "\\" + resultFileName);
				historyVo.setJobId(executeVo.getJobId());
				historyVo.setStepSeq(executeVo.getStepSeq());
				historyVo.setEndDate(new Date(resultFile.lastModified())); // result 파일 생성시간 = 종료시간
				executeDao.updateHistory(historyVo);

				if( RESULT_FAIL.equals( historyVo.getResult() ) ){
					// 실패 이력은 FAIL테이블에 추가
					File failSaveFile = new File( SGKUtil.getConfig("FILE_JOBS_PATH") + "\\" + resultFileName );
					SGKHistoryFailVo historyFailVo = new SGKHistoryFailVo();
					historyFailVo.setQueueSeq( historyVo.getQueueSeq() );
					historyFailVo.setJobId( executeVo.getJobId() );
					historyFailVo.setStepSeq( executeVo.getStepSeq() );
					historyFailVo.setFailLog( SGKUtil.getFileContent( failSaveFile ) );

					// job step에 따른 ErrorCode 처리
					String mappingCode = executeVo.getJobId() + "," + executeVo.getStepSeq();
					if(this.stepVoMap.containsKey(mappingCode)) {
						historyFailVo.setErrorCode(this.stepVoMap.get(mappingCode).getStepMappingError());
					}

					executeDao.insertHistoryFail( historyFailVo );

					// process kill
					String pidPath = SGKUtil.getConfig("FILE_PIDS_PATH") + executeVo.getQueueSeq() + ".pid";
					SGKUtil.killProcess(properties.get("sgkJob", "TASK_KILL_COMMAND"), pidPath);
				} else {
					// 성공일 경우 후처리 진행
					// 후처리 결과 조회 후 vo에 셋팅
					executeVo.setStepResult(SGKUtil.getFileContent(resultFile));
					this.jobObjectMap.get(executeVo.getJobId()).callback(executeVo);
				}
			}
		} catch (Exception e) {
			// ERR00-003 : job 이력정보 갱신 불가
			throw new SgkJobException("ERR00-003", "resultFileName : " + targetResultFileName, e);
		}

	}

	// EXECUTE 목록 갱신
	public void updateExecute() throws SgkJobException {

		try {
			// jobs 폴더 밑의 결과가 있는 execute만 실행
			for (String resultFileName : this.resultFiles) {
				SGKHistoryVo historyVo = SGKUtil.fileNameToHistroyVo( resultFileName );
				// STEP이 없는 경우 제거
				executeDao.deleteExecuteByHasntNext(historyVo.getQueueSeq());

				// STEP이 있는 경우 STEP 증가
				SGKExecuteVo executeVo = new SGKExecuteVo();
				executeVo.setQueueSeq(historyVo.getQueueSeq());
				executeVo.setUpdateDate(new Date());
				executeDao.updateExecuteStepByHasNext(executeVo);
			}

			// 현재 SERVER의 실행 개수 조회
			int executeCount = executeDao.selectExecuteListCount(SGKUtil.getConfig("TARGET_SERVER"));
			// 한 번에 실행할 수 있는 최대 수
			int limitCount = Integer.parseInt(properties.get("sgkJob", "EXECUTE_LIMIT"));
			// 이번에 queue에서 가져올 수
			int moveCount = limitCount - executeCount;

			// TB_SGK_JOB_QUEUE lock
			executeDao.lockQueueTable();

			// TB_SGK_JOB_EXECUTE의 데이터가 EXECUTE_LIMIT보다 낮은 경우, execute데이터를 추가
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put("targetServer", SGKUtil.getConfig("TARGET_SERVER"));
			paramMap.put("moveCount", moveCount);
			List<SGKQueueVo> moveQueueList = executeDao.selectMoveQueueList(paramMap);

			// 추가된 파일이 실행되야 하므로 success 목록에 추가
			for (SGKQueueVo moveQueueVo : moveQueueList) {
				// QUEUE에서 삭제
				executeDao.deleteQueue(moveQueueVo.getQueueSeq());
			}

			// TB_SGK_JOB_QUEUE unlock
			executeDao.unlockQueueTable();

			// 추가된 파일이 실행되야 하므로 success 목록에 추가
			for (SGKQueueVo moveQueueVo : moveQueueList) {
				// EXECUTE로 이동(insert)
				SGKExecuteVo executeVo = new SGKExecuteVo();
				executeVo.setQueueSeq(moveQueueVo.getQueueSeq());
				executeVo.setJobId(moveQueueVo.getJobId());
				executeVo.setStepSeq(1);
				executeVo.setJobData(moveQueueVo.getJobData());
				executeVo.setTargetServer(SGKUtil.getConfig("TARGET_SERVER"));
				executeVo.setRegDate(new Date());
				executeVo.setUpdateDate(new Date());
				executeDao.insertExecute(executeVo);

				// 실행을 위함 JOB파일 추가
				this.resultFiles.add(moveQueueVo.getQueueSeq() + "#SUCCESS.job");
			}
		} catch (Exception e) {
			// ERR00-006 : 변환단계 진행불가 오류
			throw new SgkJobException("ERR00-006", e);
		}
	}

	// 현재 생성된 결과파일목록 조회
	public void getResultFiles() throws SgkJobException {

		try {
			// RESULT_PATH 조회
			List<String> resultFiles = new ArrayList<String>();
			Collections.addAll(resultFiles, new File( SGKUtil.getConfig("FILE_JOBS_PATH") ).list());
			this.resultFiles = resultFiles;
		} catch (Exception e) {
			// ERR00-002 : 결과파일 목록 조회 불가
			throw new SgkJobException("ERR00-002", e);
		}
	}

	// 결과 파일을 모두 제거
	public void removeResultFiles() throws SgkJobException {
		String targetResultFileName = "";
		try {
			for (String resultFileName : this.resultFiles) {
				// jobs
				targetResultFileName = resultFileName;
				SGKUtil.fileRemove(SGKUtil.getConfig("FILE_JOBS_PATH") + "\\" + resultFileName);
				// pids
				String queueSeq = resultFileName.substring(0, resultFileName.indexOf("#"));
				SGKUtil.fileRemove(SGKUtil.getConfig("FILE_PIDS_PATH") + queueSeq+ ".pid");
			}
		} catch (Exception e) {
			// ERR00-005 : 결과파일 제거 오류
			throw new SgkJobException("ERR00-005", "resultFileName : " + targetResultFileName, e);
		}
	}

	// 작업에 실패한 JOB_EXECUTE 제거
	public void deleteFailExecute() throws SgkJobException {
		String targetResultFileName = "";
		try {
			for (String resultFileName : this.resultFiles) {
				targetResultFileName = resultFileName;
				SGKHistoryVo historyVo = SGKUtil.fileNameToHistroyVo( resultFileName );
				if( RESULT_FAIL.equals( historyVo.getResult() ) ){
					executeDao.deleteExecute( historyVo.getQueueSeq() );
				}
			}
		} catch (Exception e) {
			// ERR00-004 : JOB Execute 삭제 오류
			throw new SgkJobException("ERR00-004","resultFileName : " + targetResultFileName, e);
		}

	}

	/**
	 * 1시간 마다 monitor 데이터 삭제
	 */
	public void deleteMonitor() throws SgkJobException {
		try {
			executeDao.deleteMonitor();
		} catch (Exception e) {
			// ERR00-010 : Monitor 테이블 삭제 오류
			throw new SgkJobException("ERR00-010","Monitor 테이블 삭제 오류", e);
		}
	}

	/**
	 * exception 발생 시 처리
	 * 1. execute 테이블에서 삭제
	 * 2. history 테이블 fail 처리
	 * 3. history fail 테이블 등록
	 * @param jobException
	 */
	public void executeJobException(SgkJobException jobException) {
		SGKHistoryVo historyVo = null;
		SGKHistoryFailVo historyFailVo = null;

		try {
			SGKExecuteVo targetExecuteVo = jobException.getExecuteVo();

			if(targetExecuteVo != null) {
				// execute 테이블에서 삭제
				executeDao.deleteExecute(targetExecuteVo.getQueueSeq());

				// history 테이블 fail 처리
				historyVo = new SGKHistoryVo();
				historyVo.setEndDate(new Date());
				historyVo.setResult(RESULT_FAIL);
				historyVo.setQueueSeq(targetExecuteVo.getQueueSeq());
				historyVo.setJobId(targetExecuteVo.getJobId());
				historyVo.setStepSeq(targetExecuteVo.getStepSeq());
				executeDao.updateHistory(historyVo);
			}

			// history fail 테이블 등록
			historyFailVo = new SGKHistoryFailVo();
			historyFailVo.setQueueSeq(targetExecuteVo.getQueueSeq());
			historyFailVo.setJobId(targetExecuteVo.getJobId());
			historyFailVo.setStepSeq(targetExecuteVo.getStepSeq());
			historyFailVo.setErrorCode(jobException.getErrorCode());
			historyFailVo.setFailLog(jobException.getJobFailLog());
			executeDao.insertHistoryFail(historyFailVo);

		} catch (Exception e) {
			logger.error("### executeJobException ERROR!!!!!!!!");
			e.printStackTrace();
		}

	}
}