package com.sehyunict.smartgeokit.batch.sgk.vo;

public class SGKHistoryFailVo {

	private Integer queueSeq;
	private String jobId;
	private Integer stepSeq;
	private String failLog;
	private String errorCode;
	
	public Integer getQueueSeq() {
		return queueSeq;
	}
	public void setQueueSeq( Integer queueSeq ) {
		this.queueSeq = queueSeq;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId( String jobId ) {
		this.jobId = jobId;
	}
	public Integer getStepSeq() {
		return stepSeq;
	}
	public void setStepSeq( Integer stepSeq ) {
		this.stepSeq = stepSeq;
	}
	public String getFailLog() {
		return failLog;
	}
	public void setFailLog( String failLog ) {
		this.failLog = failLog;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
	@Override
	public String toString() {
		return "SGKHistoryFailVo [queueSeq=" + queueSeq + ", jobId=" + jobId + ", stepSeq=" + stepSeq + ", failLog="
				+ failLog + "]";
	}

}
