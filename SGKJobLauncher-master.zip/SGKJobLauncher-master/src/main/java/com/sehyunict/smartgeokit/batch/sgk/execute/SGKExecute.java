package com.sehyunict.smartgeokit.batch.sgk.execute;

import com.sehyunict.smartgeokit.batch.sgk.vo.SGKExecuteVo;

public interface SGKExecute {

	/**
	 * 실행
	 * @param sgkExecuteVo
	 * @throws Exception
	 */
	public abstract void execute(SGKExecuteVo sgkExecuteVo) throws Exception;

	/**
	 * 콜백
	 * @param sgkExecuteVo
	 * @throws Exception
	 */
	public abstract void callback(SGKExecuteVo sgkExecuteVo) throws Exception;

}
