package com.sehyunict.smartgeokit.batch.cad.vo;

import java.util.Date;

public class SGKCadDwgVo {

	private String dwgId;
	private String dwgName;
	private String filePath;
	private Date regDate;

	public String getDwgId() {
		return dwgId;
	}
	public void setDwgId(String dwgId) {
		this.dwgId = dwgId;
	}
	public String getDwgName() {
		return dwgName;
	}
	public void setDwgName(String dwgName) {
		this.dwgName = dwgName;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
}
