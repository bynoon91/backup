package com.sehyunict.smartgeokit.batch.cad.vo;

import java.util.Date;

public class SGKCadIndexVo {

	private String indexId;
	private String indexType;
	private Integer blockFileCnt;
	private Integer indexFileCnt;
	private Date regDate;

	public String getIndexId() {
		return indexId;
	}
	public void setIndexId(String indexId) {
		this.indexId = indexId;
	}
	public String getIndexType() {
		return indexType;
	}
	public void setIndexType(String indexType) {
		this.indexType = indexType;
	}
	public Integer getBlockFileCnt() {
		return blockFileCnt;
	}
	public void setBlockFileCnt(Integer blockFileCnt) {
		this.blockFileCnt = blockFileCnt;
	}
	public Integer getIndexFileCnt() {
		return indexFileCnt;
	}
	public void setIndexFileCnt(Integer indexFileCnt) {
		this.indexFileCnt = indexFileCnt;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
}
