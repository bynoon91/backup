package com.sehyunict.smartgeokit.batch.sgk;

import java.io.File;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.sehyunict.smartgeokit.batch.exception.SgkJobException;
import com.sehyunict.smartgeokit.batch.sgk.service.SGKExecuteService;
import com.sehyunict.smartgeokit.batch.sgk.util.SGKProperties;
import com.sehyunict.smartgeokit.batch.sgk.util.SGKUtil;

@Component
public class SGKJobLauncher {

	@Autowired
	private SGKExecuteService sgkExecuteService;

	public SGKJobLauncher() {}

	// 최초 한번만 실행되는 함수
	public SGKJobLauncher(SGKProperties properties) throws Exception {
		String fileJobsPath = SGKUtil.getConfig("SGKJL_ROOT_PATH") + String.format(properties.get("sgkJob", "FILE_JOBS_PATH"), SGKUtil.getConfig("TARGET_SERVER"));
		String filePidsPath = SGKUtil.getConfig("SGKJL_ROOT_PATH") + String.format(properties.get("sgkJob", "FILE_PIDS_PATH"), SGKUtil.getConfig("TARGET_SERVER"));

		// config에 추가
		SGKUtil.setConfig("FILE_JOBS_PATH", fileJobsPath);
		SGKUtil.setConfig("FILE_PIDS_PATH", filePidsPath);
		
		// 서버 별 필요한 폴더 생성
		new File(fileJobsPath).mkdirs();
		new File(filePidsPath).mkdirs();
	}

	/**
	 * SgkLauncher 실행
	 */
	@Scheduled(fixedRate=1000)
	public void sgkExecute() {
		try {

			// RESULT_FILE 조회
			sgkExecuteService.getResultFiles();

			// JOB_HISTROY 저장 및 단계 종료후 callback 실행
			sgkExecuteService.saveHistory();

			// 작업에 실패한 JOB_EXECUTE 제거
			sgkExecuteService.deleteFailExecute();

			// RESULT_FILE 삭제
			sgkExecuteService.removeResultFiles();

			// JOB_EXECUTE 갱신
			sgkExecuteService.updateExecute();

			// JOB_EXECUTE 조회
			sgkExecuteService.getExecutes();

			// JOB을 실행
			sgkExecuteService.run();

		} catch (SgkJobException e) {
			sgkExecuteService.executeJobException(e);
		}
	}

	/**
	 * 1시간 마다 monitor 데이터 삭제
	 */
	@Scheduled(fixedRate=1000 * 60 * 60)
	public void deleteMonitor() {
		try {
			sgkExecuteService.deleteMonitor();
		} catch (SgkJobException e) {
			sgkExecuteService.executeJobException(e);
		}
	}
}
