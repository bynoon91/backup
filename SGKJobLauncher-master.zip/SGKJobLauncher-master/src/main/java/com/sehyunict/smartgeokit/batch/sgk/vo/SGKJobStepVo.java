package com.sehyunict.smartgeokit.batch.sgk.vo;

public class SGKJobStepVo {

	private String jobId; // 작업 식별 정보
	private Integer stepSeq; // 작업순번 = 단계
	private String stepDesc; // 단계설명
	private String stepMappingError; // 단계별 에러코드 Mapping
	
	public String getJobId() {
		return jobId;
	}
	public void setJobId( String jobId ) {
		this.jobId = jobId;
	}
	public Integer getStepSeq() {
		return stepSeq;
	}
	public void setStepSeq( Integer stepSeq ) {
		this.stepSeq = stepSeq;
	}
	public String getStepDesc() {
		return stepDesc;
	}
	public void setStepDesc( String stepDesc ) {
		this.stepDesc = stepDesc;
	}
	public String getStepMappingError() {
		return stepMappingError;
	}
	public void setStepMappingError(String stepMappingError) {
		this.stepMappingError = stepMappingError;
	}
	@Override
	public String toString() {
		return "SGKStepVo [jobId=" + jobId + ", stepSeq=" + stepSeq + ", stepDesc=" + stepDesc + ", stepErrorMapping=" + stepMappingError + "]";
	}

}
