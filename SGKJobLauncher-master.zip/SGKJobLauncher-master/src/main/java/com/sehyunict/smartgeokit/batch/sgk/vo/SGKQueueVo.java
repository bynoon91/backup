package com.sehyunict.smartgeokit.batch.sgk.vo;

import java.util.Date;

public class SGKQueueVo {

	private Integer queueSeq;
	private String jobId;
	private String jobData;
	private Date regDate;

	public Integer getQueueSeq() {
		return queueSeq;
	}
	public void setQueueSeq(Integer queueSeq) {
		this.queueSeq = queueSeq;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public String getJobData() {
		return jobData;
	}
	public void setJobData(String jobData) {
		this.jobData = jobData;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	@Override
	public String toString() {
		return "SGKQueueVo [queueSeq=" + queueSeq + ", jobId=" + jobId + ", jobData=" + jobData + ", regDate=" + regDate
				+ "]";
	}

}
