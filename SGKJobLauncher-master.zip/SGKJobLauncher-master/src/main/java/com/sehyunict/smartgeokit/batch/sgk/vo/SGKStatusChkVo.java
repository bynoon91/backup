package com.sehyunict.smartgeokit.batch.sgk.vo;

public class SGKStatusChkVo {

	private int queueSeq;
	private String jobId;
	private int stepSeq;
	private String stepSeqNm;
	private int totalStepCount;
	private String result;

	public int getQueueSeq() {
		return queueSeq;
	}
	public void setQueueSeq(int queueSeq) {
		this.queueSeq = queueSeq;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public int getStepSeq() {
		return stepSeq;
	}
	public void setStepSeq(int stepSeq) {
		this.stepSeq = stepSeq;
	}
	public String getStepSeqNm() {
		return stepSeqNm;
	}
	public void setStepSeqNm(String stepSeqNm) {
		this.stepSeqNm = stepSeqNm;
	}
	public int getTotalStepCount() {
		return totalStepCount;
	}
	public void setTotalStepCount(int totalStepCount) {
		this.totalStepCount = totalStepCount;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
}
