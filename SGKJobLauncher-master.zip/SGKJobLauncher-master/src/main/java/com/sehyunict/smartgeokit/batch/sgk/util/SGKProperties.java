package com.sehyunict.smartgeokit.batch.sgk.util;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;

@Component("SGKProperties")
public class SGKProperties {

	@Autowired
	private ApplicationContext context;

	@SuppressWarnings( "unchecked" )
	public String get( String appName, String key ){
		Map<String, String> properties = (Map<String, String>)context.getBean(appName);
		return properties.get(key);
	}
}
