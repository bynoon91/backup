package com.sehyunict.smartgeokit.batch.sgk.vo;

public class SGKJobParseVo {

	private String dwgId;
	private int revNo;
	private String filePath;
	private String enableCadYn;
	private String enableTileYn;
	private String stepResult;

	private int queueSeq;
	private String revFilePath;
	
	private String dmsRevFilePath;
	private String sgkRevFilePath;
	
	public String getDwgId() {
		return dwgId;
	}
	public void setDwgId(String dwgId) {
		this.dwgId = dwgId;
	}
	public int getRevNo() {
		return revNo;
	}
	public void setRevNo(int revNo) {
		this.revNo = revNo;
	}
	public String getFilePath() {
		return filePath;
	}
	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}
	public String getEnableCadYn() {
		return enableCadYn;
	}
	public void setEnableCadYn(String enableCadYn) {
		this.enableCadYn = enableCadYn;
	}
	public String getEnableTileYn() {
		return enableTileYn;
	}
	public void setEnableTileYn(String enableTileYn) {
		this.enableTileYn = enableTileYn;
	}
	public int getQueueSeq() {
		return queueSeq;
	}
	public void setQueueSeq(int queueSeq) {
		this.queueSeq = queueSeq;
	}
	public String getRevFilePath() {
		return revFilePath;
	}
	public void setRevFilePath(String revFilePath) {
		this.revFilePath = revFilePath;
	}
	public String getStepResult() {
		return stepResult;
	}
	public void setStepResult(String stepResult) {
		this.stepResult = stepResult;
	}
	public String getDmsRevFilePath() {
		return dmsRevFilePath;
	}
	public void setDmsRevFilePath(String dmsRevFilePath) {
		this.dmsRevFilePath = dmsRevFilePath;
	}
	public String getSgkRevFilePath() {
		return sgkRevFilePath;
	}
	public void setSgkRevFilePath(String sgkRevFilePath) {
		this.sgkRevFilePath = sgkRevFilePath;
	}
}
