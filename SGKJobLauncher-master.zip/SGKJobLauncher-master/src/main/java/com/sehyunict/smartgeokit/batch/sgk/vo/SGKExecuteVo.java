package com.sehyunict.smartgeokit.batch.sgk.vo;

import java.util.Date;

/**
 * @author mangu
 * @desc Queue value object
 */
public class SGKExecuteVo {

	private Integer queueSeq;	// queue 식별 아이디
	private String jobId;			// job 식별 아이디
	private Integer stepSeq;		// step 식별 아이디
	private String jobData;		// job 파라미터
	private String targetServer;	// 실행서버
	private Date regDate;			// 등록일
	private Date updateDate;	// 수정일
	private String stepResult;	// 각 단계 종료후 받아 오는 결과

	public Integer getQueueSeq() {
		return queueSeq;
	}
	public void setQueueSeq(Integer queueSeq) {
		this.queueSeq = queueSeq;
	}
	public String getJobId() {
		return jobId;
	}
	public void setJobId(String jobId) {
		this.jobId = jobId;
	}
	public Integer getStepSeq() {
		return stepSeq;
	}
	public void setStepSeq(Integer stepSeq) {
		this.stepSeq = stepSeq;
	}
	public String getJobData() {
		return jobData;
	}
	public void setJobData(String jobData) {
		this.jobData = jobData;
	}
	public String getTargetServer() {
		return targetServer;
	}
	public void setTargetServer(String targetServer) {
		this.targetServer = targetServer;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getStepResult() {
		return stepResult;
	}
	public void setStepResult(String stepResult) {
		this.stepResult = stepResult;
	}

	@Override
	public String toString() {
		return "SGKExecuteVo [queueSeq=" + queueSeq + ", jobId=" + jobId + ", stepSeq=" + stepSeq + ", jobData="
				+ jobData + ", regDate=" + regDate + "]";
	}
}
