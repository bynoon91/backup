package com.sehyunict.smartgeokit.batch.sgk.execute.job;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sehyunict.smartgeokit.batch.cad.vo.SGKCadDwgVo;
import com.sehyunict.smartgeokit.batch.exception.SgkJobException;
import com.sehyunict.smartgeokit.batch.sgk.dao.SGKCadDAO;
import com.sehyunict.smartgeokit.batch.sgk.execute.SGKExecute;
import com.sehyunict.smartgeokit.batch.sgk.util.SGKUtil;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKCompareVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKExecuteVo;

/**
 * 
 * @author js
 * @desc compare 
 */
@Component(value="COMPARE")
public class SGKCompare implements SGKExecute {

	private static final Logger logger = LogManager.getLogger(SGKCompare.class);

	@Autowired
	private SGKCadDAO dao;

	/**
	 * preset
	 */
	@Override
	public void execute(SGKExecuteVo sgkExecuteVo) throws SgkJobException {
		
		SGKCompareVo compareVo = compareInit(sgkExecuteVo);
		
		// job!!!
		switch (sgkExecuteVo.getStepSeq()) {
			case 1:
				this.createDiff(sgkExecuteVo, compareVo);
//				this.createDiffUseNode(sgkExecuteVo, compareVo);
				break;
		}
	}
		
	/**
	 * callback
	 */
	@Override
	public void callback(SGKExecuteVo sgkExecuteVo) throws SgkJobException {
		
		SGKCompareVo compareVo = compareInit(sgkExecuteVo);
		
		switch (sgkExecuteVo.getStepSeq()) {
		case 1:
			this.saveCompareResult(sgkExecuteVo, compareVo);
			break;
		}
	}

	/**
	 * compare init
	 * @throws Exception
	 */
	public SGKCompareVo compareInit(SGKExecuteVo sgkExecuteVo) throws SgkJobException {
		
		SGKCompareVo compareVo = new SGKCompareVo();
		
		// vo validation
		this.validationSGKExecuteVo(sgkExecuteVo);
		
		// job data validation
		this.validationJobData(sgkExecuteVo, compareVo);
		
		// get dwg path
		this.getRevisionFilePath(compareVo);
		
		return compareVo;
	}
	
	/**
	 * get dwg path
	 * @throws Exception
	 */
	private void getRevisionFilePath(SGKCompareVo compareVo) throws SgkJobException {
		
		SGKCadDwgVo dwgVo = new SGKCadDwgVo();
		try {
			dwgVo = dao.selectCadDwg(compareVo.getDwgId());
			compareVo.setDwgPath(SGKUtil.getConfig("SGK_DATA_PATH") + dwgVo.getFilePath());
		} catch(Exception e) {
			throw new SgkJobException("ERR05-001", "dwgPath : " + dwgVo.getFilePath() + ", cause : dwg path 이상", e);
		}
	}

	/**
	 * validation SGKExecuteVo
	 * @param param
	 * @throws SgkJobException
	 */
	private void validationSGKExecuteVo(SGKExecuteVo sgkExecuteVo) throws SgkJobException {
		
		// read data NULL check
		if(SGKUtil.isEmpty(sgkExecuteVo)) {
			throw new SgkJobException("ERR05-001", "cause : SGKExecuteVo is null");
		}

		// job data null check
		if(SGKUtil.isEmpty(sgkExecuteVo.getJobData())) {
			throw new SgkJobException("ERR05-001", "jobData is null");
		}
	}

	/**
	 * job data validation
	 * @throws SgkJobException 
	 */
	private void validationJobData(SGKExecuteVo sgkExecuteVo, SGKCompareVo compare) throws SgkJobException {
		
		/**
		 * data structure : DWG_ID,revision1,revision2
		 * target name = DWG_ID
		 * revision1 = pivot revision
		 * revidion2 = differ revision
		 * 
		 * terms1 : 3개의 데이터는 모두 필수값
		 * terms2 : pivot&differ revision = 숫자
		 * terms3 : pivot revision != differ revision
		 * 
		 * # DWG_ID에 구분자 ','가 포함될 경우가 있음
		 */
		compare.setJobData(sgkExecuteVo.getJobData().trim());
		String [] tmpJobDataArr = compare.getJobData().split(",");
		
		if(SGKUtil.isEmpty(tmpJobDataArr[2])) {
			throw new SgkJobException("ERR05-001", "cause : differ revision null");
		} else if(!SGKUtil.isNumber(tmpJobDataArr[2])) {
			throw new SgkJobException("ERR05-001", "cause : differ revision 이상");
		}
		compare.setDifferRevNo(Integer.valueOf(tmpJobDataArr[2]));
		
		if(SGKUtil.isEmpty(tmpJobDataArr[1])) {
			throw new SgkJobException("ERR05-001", "cause : pivot revision null");
		} else if(!SGKUtil.isNumber(tmpJobDataArr[1])) {
			throw new SgkJobException("ERR05-001", "cause : pivot revision 이상");
		} else if(tmpJobDataArr[2].equals(tmpJobDataArr[1])) {
			throw new SgkJobException("ERR05-001", "cause : 동일한 revision 선택");
		}
		compare.setPivotRevNo(Integer.valueOf(tmpJobDataArr[1]));
		
		if(SGKUtil.isEmpty(tmpJobDataArr[0])) {
			throw new SgkJobException("ERR05-001", "cause : 도면ID 이상");
		}
		compare.setDwgId(tmpJobDataArr[0]);
	}

	/**
	 * compare 결과 저장
	 * @param sgkExecuteVo
	 * @throws Exception
	 */
	private void saveCompareResult(SGKExecuteVo sgkExecuteVo, SGKCompareVo compareVo) throws SgkJobException {
		
		try {
			String pivotPath = SGKUtil.getConfig("SGKJL_ROOT_PATH");
			pivotPath += compareVo.getDwgPath() + "/" + compareVo.getPivotRevNo() + "/";
			pivotPath += SGKUtil.getConfig("FILE_DIFF_PATH") + compareVo.getDifferRevNo() + "/";
			
			String differPath = SGKUtil.getConfig("SGKJL_ROOT_PATH");
			differPath += compareVo.getDwgPath() + "/" + compareVo.getDifferRevNo() + "/";
			differPath += SGKUtil.getConfig("FILE_DIFF_PATH") + compareVo.getPivotRevNo() + "/";
			
			String pivotWdfsPath = SGKUtil.getConfig("SGKJL_ROOT_PATH");
			pivotWdfsPath += compareVo.getDwgPath() + "/" + compareVo.getPivotRevNo() + "/";
			pivotWdfsPath += SGKUtil.getConfig("FILE_WDFS_PATH") + SGKUtil.getConfig("FILE_DIFF_PATH");
			pivotWdfsPath += compareVo.getDifferRevNo() + "/" + SGKUtil.getConfig("FILE_BITCODE_PATH");
			
			String differWdfsPath = SGKUtil.getConfig("SGKJL_ROOT_PATH");
			differWdfsPath += compareVo.getDwgPath() + "/" + compareVo.getDifferRevNo() + "/";
			differWdfsPath += SGKUtil.getConfig("FILE_WDFS_PATH") + SGKUtil.getConfig("FILE_DIFF_PATH");
			differWdfsPath += compareVo.getPivotRevNo() + "/" + SGKUtil.getConfig("FILE_BITCODE_PATH");
			
			String [] resultArray = sgkExecuteVo.getStepResult().split("_");
			
			// result validation
			if(resultArray.length != 2) {
				throw new Exception("compare result error : " + Arrays.toString(resultArray));
			}
			
			compareVo.setPivotPath(pivotPath);
			compareVo.setPivotWdfsPath(pivotWdfsPath);
			compareVo.setDifferPath(differPath);
			compareVo.setDifferWdfsPath(differWdfsPath);
			compareVo.setChangeRate(Double.valueOf(resultArray[1]));
			
			// compare result에 따른 분기처리 => "_"로 분리하여 결과 / 변경율 get
			this.saveDiffCompare(sgkExecuteVo, compareVo);
			
			// save success file
			SGKUtil.saveFile(SGKUtil.getConfig("FILE_JOBS_PATH") + sgkExecuteVo.getQueueSeq() + "#SUCCESS.job", "");
		} catch (Exception e) {
			throw new SgkJobException("ERR05-003", e);
		}

	}

	/**
	 * save compare
	 * @param sgkExecuteVo
	 * @param isPivot
	 * @throws Exception
	 */
	private void saveDiffCompare(SGKExecuteVo sgkExecuteVo, SGKCompareVo compareVo) throws Exception {
		
		if(Integer.valueOf(compareVo.getPivotRevNo()) > Integer.valueOf(compareVo.getDifferRevNo())) {
			compareVo.setUpRevNo(compareVo.getPivotRevNo());
			compareVo.setLowRevNo(compareVo.getDifferRevNo());
		} else {
			compareVo.setUpRevNo(compareVo.getDifferRevNo());
			compareVo.setLowRevNo(compareVo.getPivotRevNo());
		}
		
		compareVo.setUpBlockCnt(1);
		compareVo.setUpIndexCnt(getFileCount(compareVo.getPivotWdfsPath()));
		compareVo.setLowBlockCnt(1);
		compareVo.setLowIndexCnt(getFileCount(compareVo.getDifferWdfsPath()));
		compareVo.setRegDate(new Date());
		
		dao.insertCompare(compareVo);
	}
	
	/**
	 * get file count
	 * @param path
	 * @return
	 * @throws Exception
	 */
	private int getFileCount(String path) throws Exception {
		
		int cnt = 0;
		
		String[] fileList = new File(path).list();
		cnt = fileList.length;
		
		return cnt;
	}
	
	/**
	 * create diff use compare.exe
	 * @param sgkExecuteVo
	 * @throws SgkJobException
	 */
	private void createDiff(SGKExecuteVo sgkExecuteVo, SGKCompareVo compareVo) throws SgkJobException {
		
		StringBuffer compareExeCmd = new StringBuffer();
		
		try {
			compareExeCmd.append(SGKUtil.getConfig("COMPARE_EXE_PATH"));
			compareExeCmd.append(" " + String.valueOf(sgkExecuteVo.getQueueSeq()));
			compareExeCmd.append(" " + compareVo.getDwgPath());
			compareExeCmd.append(" " + compareVo.getPivotRevNo());
			compareExeCmd.append(" " + compareVo.getDwgPath());
			compareExeCmd.append(" " + compareVo.getDifferRevNo());
			compareExeCmd.append(" " + SGKUtil.getConfig("FILE_JOBS_PATH"));
			compareExeCmd.append(" " + SGKUtil.getConfig("GLOBAL_CONFIG_PATH"));
			
			// run thread
			class RunThread implements Runnable {
				private String runCmd;
				public RunThread(String runCmd) {
					this.runCmd = runCmd;
				}
				@Override
				public void run() {
					try {
						logger.info(runCmd);
						
						Process proc = Runtime.getRuntime().exec(runCmd);
						BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream(), "UTF-8"));
						String line = null;
						while ((line = reader.readLine()) != null) {
							logger.info(line);
						}
						
						reader.close();
						
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			new Thread(new RunThread(compareExeCmd.toString())).start();
		} catch(Exception e) {
			throw new SgkJobException("ERR05-002", "command : " + compareExeCmd.toString(), e);
		}
	}
	
	/**
	 * create diff use compare.js
	 * @param sgkExecuteVo
	 * @throws SgkJobException
	 */
	private void createDiffUseNode(SGKExecuteVo sgkExecuteVo, SGKCompareVo compareVo) throws SgkJobException {
		
		StringBuffer nodeCompareCmd = new StringBuffer();
		
		try {
			nodeCompareCmd.append("node");
			nodeCompareCmd.append(" " + SGKUtil.getConfig("NODEJS_EXEC_OPTS"));
			nodeCompareCmd.append(" " + SGKUtil.getConfig("COMPARE_NODE_PATH"));
			nodeCompareCmd.append(" " + String.valueOf(sgkExecuteVo.getQueueSeq()));
			nodeCompareCmd.append(" " + compareVo.getDwgPath());
			nodeCompareCmd.append(" " + compareVo.getPivotRevNo());
			nodeCompareCmd.append(" " + compareVo.getDwgPath());
			nodeCompareCmd.append(" " + compareVo.getDifferRevNo());
			nodeCompareCmd.append(" " + SGKUtil.getConfig("FILE_JOBS_PATH"));
			nodeCompareCmd.append(" " + SGKUtil.getConfig("GLOBAL_CONFIG_PATH"));
			
			// run thread
			class RunThread implements Runnable {
				private String runCmd;
				public RunThread(String runCmd) {
					this.runCmd = runCmd;
				}
				@Override
				public void run() {
					try {
						logger.info(runCmd);
						
						Process proc = Runtime.getRuntime().exec(runCmd);
						BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream(), "UTF-8"));
						String line = null;
						while ((line = reader.readLine()) != null) {
							logger.info(line);
						}
						
						reader.close();
						
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
			new Thread(new RunThread(nodeCompareCmd.toString())).start();
		} catch (Exception e) {
			throw new SgkJobException("ERR05-002", "command : " + nodeCompareCmd.toString(), e);
		}
	}

	@Override
	public String toString() {
		return "SGKCompare [getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

}