package com.sehyunict.smartgeokit.batch.sgk.vo;

import java.util.Date;

public class SGKCompareVo {

	private String dwgId;
	private int upRevNo;
	private int lowRevNo;
	private double changeRate;
	private int upIndexCnt;
	private int upBlockCnt;
	private int lowIndexCnt;
	private int lowBlockCnt;
	private Date regDate;
	
	private String jobData;
	private String [] arrJobData = new String[3];
	private String dwgPath;
	private int pivotRevNo;
	private int differRevNo;
	private String pivotPath;
	private String differPath;
	private String pivotWdfsPath;
	private String differWdfsPath;
	private String [] resultArray = new String[2];

	public String getDwgId() {
		return dwgId;
	}
	public void setDwgId(String dwgId) {
		this.dwgId = dwgId;
	}
	public int getUpRevNo() {
		return upRevNo;
	}
	public void setUpRevNo(int upRevNo) {
		this.upRevNo = upRevNo;
	}
	public int getLowRevNo() {
		return lowRevNo;
	}
	public void setLowRevNo(int lowRevNo) {
		this.lowRevNo = lowRevNo;
	}
	public double getChangeRate() {
		return changeRate;
	}
	public void setChangeRate(double changeRate) {
		this.changeRate = changeRate;
	}
	public int getUpIndexCnt() {
		return upIndexCnt;
	}
	public void setUpIndexCnt(int upIndexCnt) {
		this.upIndexCnt = upIndexCnt;
	}
	public int getUpBlockCnt() {
		return upBlockCnt;
	}
	public void setUpBlockCnt(int upBlockCnt) {
		this.upBlockCnt = upBlockCnt;
	}
	public int getLowIndexCnt() {
		return lowIndexCnt;
	}
	public void setLowIndexCnt(int lowIndexCnt) {
		this.lowIndexCnt = lowIndexCnt;
	}
	public int getLowBlockCnt() {
		return lowBlockCnt;
	}
	public void setLowBlockCnt(int lowBlockCnt) {
		this.lowBlockCnt = lowBlockCnt;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
	public String getJobData() {
		return jobData;
	}
	public void setJobData(String jobData) {
		this.jobData = jobData;
	}
	public String[] getArrJobData() {
		return arrJobData;
	}
	public void setArrJobData(String[] arrJobData) {
		this.arrJobData = arrJobData;
	}
	public String getDwgPath() {
		return dwgPath;
	}
	public void setDwgPath(String dwgPath) {
		this.dwgPath = dwgPath;
	}
	public String getPivotPath() {
		return pivotPath;
	}
	public void setPivotPath(String pivotPath) {
		this.pivotPath = pivotPath;
	}
	public String getDifferPath() {
		return differPath;
	}
	public void setDifferPath(String differPath) {
		this.differPath = differPath;
	}
	public String[] getResultArray() {
		return resultArray;
	}
	public void setResultArray(String[] resultArray) {
		this.resultArray = resultArray;
	}
	public int getPivotRevNo() {
		return pivotRevNo;
	}
	public void setPivotRevNo(int pivotRevNo) {
		this.pivotRevNo = pivotRevNo;
	}
	public int getDifferRevNo() {
		return differRevNo;
	}
	public void setDifferRevNo(int differRevNo) {
		this.differRevNo = differRevNo;
	}
	public String getPivotWdfsPath() {
		return pivotWdfsPath;
	}
	public void setPivotWdfsPath(String pivotWdfsPath) {
		this.pivotWdfsPath = pivotWdfsPath;
	}
	public String getDifferWdfsPath() {
		return differWdfsPath;
	}
	public void setDifferWdfsPath(String differWdfsPath) {
		this.differWdfsPath = differWdfsPath;
	}
}
