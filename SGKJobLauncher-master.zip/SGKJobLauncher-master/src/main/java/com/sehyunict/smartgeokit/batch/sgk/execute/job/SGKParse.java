package com.sehyunict.smartgeokit.batch.sgk.execute.job;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sehyunict.smartgeokit.batch.cad.vo.SGKCadRevVo;
import com.sehyunict.smartgeokit.batch.exception.SgkJobException;
import com.sehyunict.smartgeokit.batch.sgk.dao.SGKCadDAO;
import com.sehyunict.smartgeokit.batch.sgk.util.SGKUtil;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKExecuteVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKJobParseVo;

@Component(value="PARSE")
public class SGKParse {

	private static final Logger logger = LogManager.getLogger(SGKParse.class);

	@Autowired
	private SGKCadDAO dao;

	/**
	 * getSGKJobParseVo 
	 */
	public SGKJobParseVo getSGKJobParseVo(SGKExecuteVo sgkExecuteVo) throws SgkJobException {

		String jobData = "";
		String dwgId = "";
		String revFilePath = "";
		String stepResult = "";
		int revNo = 0;
		SGKJobParseVo sgkJobParseVo = new SGKJobParseVo();

		// job data에서 dwgId와 revNo로 필요한 데이터 조회
		try {
			jobData = sgkExecuteVo.getJobData();
			dwgId = jobData.split(",")[0];
			revNo = Integer.valueOf(jobData.split(",")[1]);

			sgkJobParseVo.setDwgId(dwgId);
			sgkJobParseVo.setRevNo(revNo);
			sgkJobParseVo = dao.selectJobParseData(sgkJobParseVo);
			
			// 추가로 필요한 정보 셋팅
			sgkJobParseVo.setQueueSeq(sgkExecuteVo.getQueueSeq());
			revFilePath = sgkJobParseVo.getFilePath() + "/" + sgkJobParseVo.getRevNo() + "/";
			sgkJobParseVo.setRevFilePath(revFilePath);
			
			String dmsRevFilePath = SGKUtil.getConfig("SGKJL_ROOT_PATH") + SGKUtil.getConfig("DMS_DATA_PATH");
			dmsRevFilePath += revFilePath;
			sgkJobParseVo.setDmsRevFilePath(dmsRevFilePath);
			
			String sgkRevFilePath = SGKUtil.getConfig("SGKJL_ROOT_PATH") + SGKUtil.getConfig("SGK_DATA_PATH");
			sgkRevFilePath += revFilePath;
			sgkJobParseVo.setSgkRevFilePath(sgkRevFilePath);
			
			// 실행결과 setting
			stepResult = sgkExecuteVo.getStepResult();
			if (stepResult != null && !"".equals(stepResult.trim())) {
				sgkJobParseVo.setStepResult(stepResult);
			}
		} catch (Exception e) {
			// ERR00-008 : 도면정보 조회 및 정보 셋팅 오류
			throw new SgkJobException("ERR00-008", "dwgId : " + dwgId + ", revNo : " + revNo, e);
		}

		return sgkJobParseVo;
	}

	/**
	 * autocad 변환 작업 dxf 및 plot
	 */
	public void autocad(SGKJobParseVo sgkJobParseVo) throws SgkJobException {
		StringBuffer scrCmd = new StringBuffer();
		String acadCmd = "";

		try {
			
			// sgk revision path 초기화
			SGKUtil.removeDirectory(new File(sgkJobParseVo.getSgkRevFilePath()));
			SGKUtil.makeDirs(sgkJobParseVo.getSgkRevFilePath());
			
			// scr파일 생성
			scrCmd.append("_.Open \"" + sgkJobParseVo.getDmsRevFilePath() + sgkJobParseVo.getDwgId() + ".dwg\"\n");
			scrCmd.append("_.FILEDIA 0\n");

			// LISP load
			scrCmd.append("(load \"" + SGKUtil.getConfig("ACAD_LSP_FILE_PATH") + "\")\n");

			// dxf변환 스크립트 추가
			if ("Y".equals(sgkJobParseVo.getEnableCadYn())) {
				scrCmd.append("(KL:SaveAsDxf ");
				// pInPath
				scrCmd.append("\"" + sgkJobParseVo.getDmsRevFilePath() + "\" ");
				// pOutPath
				scrCmd.append("\"" + sgkJobParseVo.getSgkRevFilePath() + "\" ");
				// jobId - queueSeq
				scrCmd.append("\"" + SGKUtil.getConfig("FILE_JOBS_PATH") + sgkJobParseVo.getQueueSeq() + "\" ");
				// endFileYn
				scrCmd.append("\"Y\" ");
				// cadOnlyYn
				if ("Y".equals(sgkJobParseVo.getEnableTileYn()))
					scrCmd.append("\"N\" ");
				else
					scrCmd.append("\"Y\" ");
				scrCmd.append(")\n");
			}

			// plot 스크립트 추가
			if ("Y".equals(sgkJobParseVo.getEnableTileYn())) {
				scrCmd.append("(KL:ExpPngImg ");
				// pOutPath
				scrCmd.append("\"" + sgkJobParseVo.getSgkRevFilePath() + "\" ");
				// jobId - queueSeq
				scrCmd.append("\"" + SGKUtil.getConfig("FILE_JOBS_PATH") + sgkJobParseVo.getQueueSeq() + "\" ");
				scrCmd.append(")\n");
			}

			scrCmd.append("_.Quit Y\n");

			// scr 파일 생성
			String scriptPath = sgkJobParseVo.getSgkRevFilePath() + sgkJobParseVo.getDwgId() + ".scr";
			SGKUtil.saveFile(scriptPath, scrCmd.toString());

			// Autocad 처리 핸들러를 사용하여 dxf변환 및 이미지 plot을 로컬에서 처리 안함
			if ("Y".equals(SGKUtil.getConfig("ACAD_HANDLER_USE_YN"))) {
				acadCmd = SGKUtil.getConfig("ACAD_HANDLER_EXEC_CMD");
				acadCmd += " " + sgkJobParseVo.getDmsRevFilePath() + "/" + sgkJobParseVo.getDwgId() + ".dwg";
				acadCmd += " " + sgkJobParseVo.getSgkRevFilePath() + "/" + sgkJobParseVo.getDwgId() + ".scr";
				acadCmd += " " + SGKUtil.getConfig("ACAD_HANDLER_SERVER_IP");
				
				class RunThread implements Runnable {
					private String runCmd;
					public RunThread(String runCmd) {
						this.runCmd = runCmd;
					}
					@Override
					public void run() {
						try {
							// 프로세스 실행 및 pid 저장
							String pidPath =  SGKUtil.getConfig("FILE_PIDS_PATH") + sgkJobParseVo.getQueueSeq() + ".pid";
							Process proc = SGKUtil.runProcess(runCmd, pidPath);
							logger.info(runCmd);

							// log 출력
							BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream(), "UTF-8"));
							String line = null;
							while ((line = reader.readLine()) != null) {
								logger.info(line);
							}
							reader.close();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
				new Thread(new RunThread(acadCmd)).start();
			} else {
				// autocad 실행 명령어 생성
				acadCmd = SGKUtil.getConfig("ACAD_EXEC_FILE_PATH") + " " + SGKUtil.getConfig("ACAD_EXEC_OPTS") + " /b " + scriptPath;
				
				// Thread autocad 실행
				class RunThread implements Runnable {
					private String runCmd;
					public RunThread(String runCmd) {
						this.runCmd = runCmd;
					}
					@Override
					public void run() {
						try {
							// 프로세스 실행 및 pid 저장
							String pidPath =  SGKUtil.getConfig("FILE_PIDS_PATH") + sgkJobParseVo.getQueueSeq() + ".pid";
							Process proc = SGKUtil.runProcess(runCmd, pidPath);
							logger.info(runCmd);
							
							// Autocad timeout 체크
							long acadExecTimeoutSecond = Long.parseLong(SGKUtil.getConfig("ACAD_EXEC_TIMEOUT_SECOND"));
							if (!proc.waitFor(acadExecTimeoutSecond, TimeUnit.SECONDS)) {
								String failMsg = String.format("Autocad Run Timeout, %s (sec)", acadExecTimeoutSecond);
								SGKUtil.saveFile(SGKUtil.getConfig("FILE_JOBS_PATH") + sgkJobParseVo.getQueueSeq() + "#FAIL.job", failMsg);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
				new Thread(new RunThread(acadCmd)).start();
			}
		} catch (Exception e) {
			// ERR01-001 : CAD변환 오류
			throw new SgkJobException("ERR01-001", "scrCmd : " + scrCmd.toString() + ", acadCmd : " + acadCmd, e);
		}
	}

	/**
	 * dxf -> wdf -> idx변환
	 */
	public void dxf2wdf2idx(SGKJobParseVo sgkJobParseVo) throws SgkJobException {
		String dwgId = sgkJobParseVo.getDwgId();
		StringBuffer nodeJsCmd = new StringBuffer();

		// dxf도면 존재하는지 체크
		String strDxfFile = sgkJobParseVo.getSgkRevFilePath() + dwgId + ".dxf";
		File dxfFile = new File(strDxfFile);
		if (!dxfFile.exists()) {
			// ERR02-001 : dxf 미존재
			throw new SgkJobException("ERR02-001", new FileNotFoundException());
		}

		//create file folders
		try {
			SGKUtil.makeDirs(sgkJobParseVo.getSgkRevFilePath() + "wdf/");
			SGKUtil.makeDirs(sgkJobParseVo.getSgkRevFilePath() + "index/");

			nodeJsCmd.append(" " + SGKUtil.getConfig("BITCODE_PARSER_FILE_PATH"));
			nodeJsCmd.append(" " + dwgId + ".dxf");
			nodeJsCmd.append(" " + SGKUtil.getConfig("FILE_JOBS_PATH") + sgkJobParseVo.getQueueSeq());
			nodeJsCmd.append(" " + sgkJobParseVo.getSgkRevFilePath());
			nodeJsCmd.append(" " + SGKUtil.getConfig("GLOBAL_CONFIG_PATH"));
		} catch (Exception e) {
			// ERR02-002 : index 저장경로 생성 오류
			throw new SgkJobException("ERR02-002", "sgkRevFilePath : " + sgkJobParseVo.getSgkRevFilePath(), e);
		}

		// Thread nodejs 실행
		try {
			class RunThread implements Runnable {
				private String runCmd;
				public RunThread(String runCmd) {
					this.runCmd = runCmd;
				}
				@Override
				public void run() {
					try {
						// 프로세스 실행 및 pid 저장
						String pidPath =  SGKUtil.getConfig("FILE_PIDS_PATH") + sgkJobParseVo.getQueueSeq() + ".pid";
						Process proc = SGKUtil.runProcess(runCmd, pidPath);
						logger.info(runCmd);

						// log 출력
						BufferedReader reader = new BufferedReader(new InputStreamReader(proc.getInputStream(), "UTF-8"));
						String line = null;
						while ((line = reader.readLine()) != null) {
							logger.info(line);
						}
						reader.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			new Thread(new RunThread(nodeJsCmd.toString())).start();
		} catch (Exception e) {
			// ERR02-003 : index 데이터 변환 오류
			throw new SgkJobException("ERR02-003", new FileNotFoundException());
		}

	}

	/**
	 * SSL ZIP
	 */
	public void sslZip(SGKJobParseVo sgkJobParseVo) throws SgkJobException {

		String[] sslZipCmd = new String[5];

		try {
			sslZipCmd[0] = SGKUtil.getConfig("SSL_ZIP_EXEC_PATH");
			sslZipCmd[1] = "-target=add";
			sslZipCmd[2] = "-srcDir=" + sgkJobParseVo.getSgkRevFilePath();
			sslZipCmd[3] = "-jobDir=" + SGKUtil.getConfig("FILE_JOBS_PATH");
			sslZipCmd[4] = "-jobNum=" + sgkJobParseVo.getQueueSeq();

			// Thread 실행
			class RunThread implements Runnable {
				private String[] runCmd;
				public RunThread(String[] runCmd) {
					this.runCmd = runCmd;
				}
				@Override
				public void run() {
					try {
						// 프로세스 실행 및 pid 저장
						String pidPath =  SGKUtil.getConfig("FILE_PIDS_PATH") + sgkJobParseVo.getQueueSeq() + ".pid";
						SGKUtil.runProcess(runCmd, pidPath);
						logger.info(Arrays.toString(runCmd));
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}	
			new Thread(new RunThread(sslZipCmd)).start();
		} catch (Exception e) {
			// ERR03-001 : 암호화 및 압축 오류
			throw new SgkJobException("ERR03-001", "runCmd : " + Arrays.toString(sslZipCmd), e);
		}

	}

	/**
	 * Tile 이미지 생성
	 */
	public void createTile(SGKJobParseVo sgkJobParseVo) throws SgkJobException {
		String revFilePath = sgkJobParseVo.getSgkRevFilePath();
		String revFileImagePath = revFilePath + "images";
		StringBuffer tileGenCmd = new StringBuffer();

		// images 폴더 생성
		try {
			tileGenCmd.append(SGKUtil.getConfig("TILE_GEN_FILE_PATH") + "exe/php.exe");
			tileGenCmd.append(" " + SGKUtil.getConfig("TILE_GEN_FILE_PATH") + "TileGen.php");
			tileGenCmd.append(" " + revFilePath);					//source
			tileGenCmd.append(" " + revFileImagePath);	//target
			tileGenCmd.append(" " + SGKUtil.getConfig("FILE_JOBS_PATH") + sgkJobParseVo.getQueueSeq());

			SGKUtil.makeDirs(revFileImagePath);
		} catch (Exception e) {
			// ERR04-001 : image Tile 저장경로 생성 오류
			throw new SgkJobException("ERR04-001", "revFileImagePath : " + revFileImagePath, e);
		}

		// Thread tileGen 실행
		try {
			class RunThread implements Runnable {
				private String runCmd;
				public RunThread(String runCmd) {
					this.runCmd = runCmd;
				}
				@Override
				public void run() {
					try {
						// 프로세스 실행 및 pid 저장
						String pidPath =  SGKUtil.getConfig("FILE_PIDS_PATH") + sgkJobParseVo.getQueueSeq() + ".pid";
						SGKUtil.runProcess(runCmd, pidPath);
						logger.info(runCmd);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			new Thread(new RunThread(tileGenCmd.toString())).start();
		} catch (Exception e) {
			// ERR04-002 : image Tile 생성 오류
			throw new SgkJobException("ERR04-002", "tileGenCmd : " + tileGenCmd.toString(), e);
		}

	}

	/**
	 * Tile생성을 위한 plot 마친 후 ControlPoint DB에 저장
	 */
	public void saveControlPoint(SGKJobParseVo sgkJobParseVo) throws SgkJobException {
		// 실행 결과가 있고 Control Point (LBX LBY RTX RTY) 값이 존재 할 때 UPDATE
		String stepResult = "";
		try {
			stepResult = sgkJobParseVo.getStepResult();
			if (stepResult != null) {
				String[] stepResultArr = stepResult.split(" ");
				if (stepResultArr.length == 4) {
					SGKCadRevVo revVo = new SGKCadRevVo();
					revVo.setDwgId(sgkJobParseVo.getDwgId());
					revVo.setRevNo(sgkJobParseVo.getRevNo());
					revVo.setControlPointLBX(Double.parseDouble(stepResultArr[0]));
					revVo.setControlPointLBY(Double.parseDouble(stepResultArr[1]));
					revVo.setControlPointRTX(Double.parseDouble(stepResultArr[2]));
					revVo.setControlPointRTY(Double.parseDouble(stepResultArr[3]));
					dao.updateCadRev(revVo);
				}
			}
		} catch (Exception e) {
			// ERR00-009 : Image Tile 정보 저장 오류
			throw new SgkJobException("ERR00-009", "stepResult : " + stepResult, e);
		}
	}

	/**
	 * 변환 작업 완료 후 중간파일 삭제(scr, dxf, png 및 wdf, index 폴더)
	 * @param sgkJobParseVo
	 * @param sgkExecuteVo
	 * @throws SgkJobException
	 */
	public void doWhenParseComplete(SGKJobParseVo sgkJobParseVo) throws SgkJobException {
		try {
			String revFilePath = sgkJobParseVo.getSgkRevFilePath();

			// 1. scr, dxf, png 삭제
			File revDir = new File(revFilePath);
			if (revDir.exists() && revDir.isDirectory()) {
				String[] files = revDir.list();
				for (String fileNm : files) {
					if (fileNm.endsWith("scr") || fileNm.endsWith("dxf") || fileNm.endsWith("png")) {
						SGKUtil.fileRemove(revFilePath + fileNm);
					}
				}
			}
			
			// 2. wdf, index 폴더 삭제
			SGKUtil.removeDirectory(new File(revFilePath + "wdf"));
			SGKUtil.removeDirectory(new File(revFilePath + "index"));
		} catch (Exception e) {
			// ERR00-011 : 변환 작업 완료 후 중간파일 삭제시 오류
			throw new SgkJobException("ERR00-011", e);
		}
	}
}
