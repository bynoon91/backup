package com.sehyunict.smartgeokit.batch.cad.vo;

import java.util.Date;

public class SGKCadRevVo {

	private String dwgId;
	private Integer revNo;
	private String indexId;
	private String enableCadYn;
	private String enableTileYn;
	private Double controlPointLBX;
	private Double controlPointLBY;
	private Double controlPointRTX;
	private Double controlPointRTY;
	private Date regDate;

	public String getDwgId() {
		return dwgId;
	}
	public void setDwgId(String dwgId) {
		this.dwgId = dwgId;
	}
	public Integer getRevNo() {
		return revNo;
	}
	public void setRevNo(Integer revNo) {
		this.revNo = revNo;
	}
	public String getIndexId() {
		return indexId;
	}
	public void setIndexId(String indexId) {
		this.indexId = indexId;
	}
	public String getEnableCadYn() {
		return enableCadYn;
	}
	public void setEnableCadYn(String enableCadYn) {
		this.enableCadYn = enableCadYn;
	}
	public String getEnableTileYn() {
		return enableTileYn;
	}
	public void setEnableTileYn(String enableTileYn) {
		this.enableTileYn = enableTileYn;
	}
	public Double getControlPointLBX() {
		return controlPointLBX;
	}
	public void setControlPointLBX(Double controlPointLBX) {
		this.controlPointLBX = controlPointLBX;
	}
	public Double getControlPointLBY() {
		return controlPointLBY;
	}
	public void setControlPointLBY(Double controlPointLBY) {
		this.controlPointLBY = controlPointLBY;
	}
	public Double getControlPointRTX() {
		return controlPointRTX;
	}
	public void setControlPointRTX(Double controlPointRTX) {
		this.controlPointRTX = controlPointRTX;
	}
	public Double getControlPointRTY() {
		return controlPointRTY;
	}
	public void setControlPointRTY(Double controlPointRTY) {
		this.controlPointRTY = controlPointRTY;
	}
	public Date getRegDate() {
		return regDate;
	}
	public void setRegDate(Date regDate) {
		this.regDate = regDate;
	}
}
