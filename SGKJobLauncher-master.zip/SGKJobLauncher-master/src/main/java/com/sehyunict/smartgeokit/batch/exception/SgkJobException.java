package com.sehyunict.smartgeokit.batch.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

import com.sehyunict.smartgeokit.batch.sgk.util.SGKUtil;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKExecuteVo;

public class SgkJobException extends Exception {

	private static final long serialVersionUID = 1L;
	
	private Exception jobException;
	private String errorCode;
	private String jobParameter = new String("-");
	private String failLog;
	private SGKExecuteVo executeVo = new SGKExecuteVo();
	
	public SgkJobException(String errorCode, String param, Exception e) {
		this.errorCode = errorCode;
		this.jobParameter = param;
		this.jobException = e;
	}
	
	public SgkJobException(String errorCode, Exception e) {
		this.errorCode = errorCode;
		this.jobException = e;
	}
	
	public SgkJobException(String errorCode, String param, String failLog) {
		this.errorCode = errorCode;
		this.jobParameter = param;
		this.failLog = failLog;
	}
	
	public SgkJobException(String errorCode, String failLog) {
		this.errorCode = errorCode;
		this.failLog = failLog;
	}
	
	public String getErrorCode() {
		return this.errorCode;
	}
	
	
	public Exception getJobException() {
		return jobException;
	}

	public String getJobParameter() {
		return jobParameter;
	}

	public void setExecuteVo(SGKExecuteVo executeVo) {
		this.executeVo = executeVo;
	}

	public SGKExecuteVo getExecuteVo() {
		return executeVo;
	}
	
	public String getJobFailLog() {
		
		StringBuilder sb= new StringBuilder();
		
		// jobInfo
		sb.append("[JobInfo] " );
		sb.append("queueSeq: ");
		sb.append(executeVo.getQueueSeq());
		sb.append(", jobId: ");
		sb.append(executeVo.getJobId());
		sb.append(", stepSeq: ");
		sb.append(executeVo.getStepSeq());
		sb.append(", jobData: ");
		sb.append(executeVo.getJobData());
		sb.append("\n");
		
		// parameter
		sb.append("[JobParameter] ");
		sb.append(this.jobParameter);
		sb.append("\n");

		// failLog
		if(SGKUtil.isEmpty(this.failLog) && !SGKUtil.isEmpty(this.jobException)) {
			StringWriter sw = new StringWriter();
			jobException.printStackTrace(new PrintWriter(sw));
			this.failLog = sw.toString();
		}
		
		sb.append("[FailLog]\n");
		sb.append(this.failLog);
		
		return sb.toString();
	}
	
}
