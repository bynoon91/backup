package com.sehyunict.smartgeokit.batch.sgk.dao;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKExecuteVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKHistoryFailVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKHistoryVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKJobStepVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKJobVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKQueueVo;

@Repository
public class SGKExecuteDAO {

	@Autowired
	private SqlMapClient sqlManClient; 

	/**
	 * execute
	 */
	@SuppressWarnings( "unchecked" )
	public List<SGKJobVo> selectJobList() throws SQLException {
		return (List<SGKJobVo>)sqlManClient.queryForList("sgk_execute.selectJobList");
	}

	@SuppressWarnings( "unchecked" )
	public List<SGKJobStepVo> selectStepList() throws SQLException {
		return (List<SGKJobStepVo>)sqlManClient.queryForList("sgk_execute.selectStepList");
	}

	public void deleteExecute( Integer queueSeq ) throws SQLException {
		sqlManClient.delete("sgk_execute.deleteExecute", queueSeq);
	}

	public void deleteExecuteByHasntNext( Integer queueSeq ) throws SQLException {
		sqlManClient.delete("sgk_execute.deleteExecuteByHasntNext", queueSeq);
	}

	public void updateExecuteStepByHasNext( SGKExecuteVo executeVo ) throws SQLException {
		sqlManClient.update("sgk_execute.updateExecuteStepByHasNext", executeVo);
	}

	public Integer selectExecuteListCount(String targetServer) throws SQLException {
		return (Integer)sqlManClient.queryForObject("sgk_execute.selectExecuteListCount", targetServer);
	}

	@SuppressWarnings( "unchecked" )
	public List<SGKExecuteVo> selectExecuteList(String targetServer) throws SQLException {
		return (List<SGKExecuteVo>)sqlManClient.queryForList("sgk_execute.selectExecuteList", targetServer);
	}

	public void insertExecute( SGKExecuteVo executeVo ) throws SQLException {
		sqlManClient.insert("sgk_execute.insertExecute", executeVo);
	}

	public SGKExecuteVo selectExecuteByQueueSeq( Integer queueSeq ) throws SQLException {
		return (SGKExecuteVo)sqlManClient.queryForObject("sgk_execute.selectExecuteByQueueSeq", queueSeq);
	}

	public void deleteMonitor() throws SQLException {
		sqlManClient.insert("sgk_execute.deleteMonitor");
	}

	/**
	 * queue
	 */
	public int deleteQueue( Integer queueSeq ) throws SQLException {
		return sqlManClient.delete("sgk_execute.deleteQueue", queueSeq);
	}

	@SuppressWarnings( "unchecked" )
	public List<SGKQueueVo> selectMoveQueueList( Map<String, Object> param ) throws SQLException {
		return (List<SGKQueueVo>)sqlManClient.queryForList("sgk_execute.selectMoveQueueList", param);
	}

	/**
	 * history
	 */
	public void insertHistory( SGKHistoryVo historyVo ) throws SQLException {
		sqlManClient.insert("sgk_execute.insertHistory", historyVo);
	}

	public void updateHistory( SGKHistoryVo historyVo ) throws SQLException {
		sqlManClient.update("sgk_execute.updateHistory", historyVo);
	}

	public void insertHistoryFail( SGKHistoryFailVo historyFailVo ) throws SQLException {
		sqlManClient.insert("sgk_execute.insertHistoryFail", historyFailVo);
	}

	/**
	 * Transaction
	 */
	public void lockQueueTable() throws SQLException {
		sqlManClient.update("sgk_execute.lockQueueTable");
	}

	public void unlockQueueTable() throws SQLException {
		sqlManClient.update("sgk_execute.unlockQueueTable");
	}
}
