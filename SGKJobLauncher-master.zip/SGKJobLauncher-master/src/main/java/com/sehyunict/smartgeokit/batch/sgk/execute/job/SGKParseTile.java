package com.sehyunict.smartgeokit.batch.sgk.execute.job;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sehyunict.smartgeokit.batch.exception.SgkJobException;
import com.sehyunict.smartgeokit.batch.sgk.execute.SGKExecute;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKExecuteVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKJobParseVo;

@Component(value="PARSE_TILE")
public class SGKParseTile implements SGKExecute {

	@Autowired
	private SGKParse sgkParse;

	/**
	 * sgkExecuteVo의 영향 범위는 execute 메소드로 제한하자.
	 */
	@Override
	public void execute(SGKExecuteVo sgkExecuteVo) throws SgkJobException {
		SGKJobParseVo sgkJobParseVo= sgkParse.getSGKJobParseVo(sgkExecuteVo);

		switch (sgkExecuteVo.getStepSeq()) {
		case 1:
			sgkParse.autocad(sgkJobParseVo);
			break;
		case 2:
			sgkParse.createTile(sgkJobParseVo);
			break;
		}
	}

	/**
	 * callback
	 */
	@Override
	public void callback(SGKExecuteVo sgkExecuteVo) throws SgkJobException {
		SGKJobParseVo sgkJobParseVo= sgkParse.getSGKJobParseVo(sgkExecuteVo);

		switch (sgkExecuteVo.getStepSeq()) {
		case 1:
			sgkParse.saveControlPoint(sgkJobParseVo);
			break;
		case 2:
			sgkParse.doWhenParseComplete(sgkJobParseVo);
			break;
		}
	}
}