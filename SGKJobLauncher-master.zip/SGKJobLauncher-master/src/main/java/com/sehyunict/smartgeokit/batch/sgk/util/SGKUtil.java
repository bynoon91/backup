package com.sehyunict.smartgeokit.batch.sgk.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Array;
import java.math.BigDecimal;
import java.nio.channels.FileChannel;
import java.nio.file.Files;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.sehyunict.smartgeokit.batch.SGKJobLauncherRun;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKHistoryVo;

public class SGKUtil {

	/**
	 * @desc
	 * 		JOB결과파일명을 맵으로 변경 전달
	 * @example
	 * 		"77#SUCCESS" => { queueSeq: 77, result: "SUCCESS" }
	 */
	public static SGKHistoryVo fileNameToHistroyVo( String fileName ){
		String[] pieces = fileName.replace(".job", "").split("#");
		SGKHistoryVo historyVo = new SGKHistoryVo();
		historyVo.setQueueSeq( Integer.parseInt(pieces[0]) );
		historyVo.setResult( pieces[1] );
		return historyVo;
	}

	// dir 생성
	public static void makeDirs(String path) throws Exception {
		File dir = new File(path);
		if (!dir.exists()) dir.mkdirs();
	}

	// 날짜포맷 dir명 구하기 yyyy/MM/dd
	public static String getFormatStrDt(String format, Date date) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat(format);
		return sdf.format(date);
	}

	// 파일 저장
	public static void saveFile(String filePath, long fileContents) throws Exception {
		saveFile(filePath, String.valueOf(fileContents));
	}
	public static void saveFile(String filePath, String fileContents) throws Exception {
		FileWriter w = new FileWriter(new File(filePath));
		w.write(fileContents);
		w.flush();
		w.close();
	}

	//파일을 복사하는 메소드
	public static boolean fileCopy(String inFileName, String outFileName) throws Exception {
		File orgFile = new File(inFileName);
		if( orgFile.exists() ){
			FileInputStream inputStream = new FileInputStream(orgFile);
			FileOutputStream outputStream = new FileOutputStream(outFileName); 
			FileChannel fcin =  inputStream.getChannel();
			FileChannel fcout = outputStream.getChannel(); 

			long size = fcin.size();
			fcin.transferTo(0, size, fcout); 

			fcout.close();
			fcin.close(); 
			outputStream.close();
			inputStream.close();
			return true;
		}
		return false;
	}

	/**
	 * 파일을 삭제한다.
	 * @param fileFullPath (파일경로 + 파일명 + 확장자)
	 * @throws Exception
	 */
	public static void fileRemove(String fileFullPath) throws Exception{
		File targetFile = new File(fileFullPath);
		targetFile.delete();
	}
	
	/**
	 * 디렉토리와 하위 파일 전체 삭제 (디렉토리 경로)
	 * @param path (삭제할 디렉토리)
	 * @throws Exception
	 */
	public static void removeDirectory(File path) throws Exception{
		
		if(path.exists()) {
			
			File[] files = path.listFiles();
			
			for(File file : files) {
				if(file.isDirectory()) {
					removeDirectory(file);
				} else {
					file.delete();
				}
			}
		}
		path.delete();
	}

	public static Map<String, String> readFileToMap(String file, String splitStr) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		BufferedReader br = new BufferedReader(new FileReader(file));
		String line;
		while ((line = br.readLine()) != null) {
			String[] arr = line.split(splitStr);
			if (arr != null && arr.length == 2) {
				map.put(arr[0], arr[1]);
			}
		}
		br.close();
		return map;
	}

	// Random Key 발생 : timestamp + "_" + 난수6자리 숫자
	public static String getRandomKey() {
		Random r = new Random();
		String key = new Date().getTime() + "_" + r.nextInt(1000000);//0~999999
		return key;
	}

	public static String strArrConcat( String[] array, String concatWord ){
		StringBuffer sb = new StringBuffer();
		for (String str : array) {
			sb.append(str);
			sb.append(concatWord);
		}
		sb.substring(0, sb.length()-1);
		return sb.toString();
	}

	// 배열[2] + 배열[3] = new 배열[5]
	public static <T> T[] arrayConcat (T[] a, T[] b) {
		int aLen = a.length;
		int bLen = b.length;

		@SuppressWarnings("unchecked")
		T[] c = (T[]) Array.newInstance(a.getClass().getComponentType(), aLen+bLen);
		System.arraycopy(a, 0, c, 0, aLen);
		System.arraycopy(b, 0, c, aLen, bLen);

		return c;
	}


	// A = [1,2,3,4,5] --> 리턴값: 1, A: [2,3,4,5] 
	public static <T> T listShift( List<T> list ) {
		T item = null;
		if( list.size() > 0 ){
			item = list.get(0);
			list.remove(0);
		}
		return item;
	}

	/**
	 * Object empty check
	 * @param Object
	 * @return boolean
	 */
	public static boolean isEmpty(Object obj) {
		if (obj == null) {
			return true;
		} else if (obj instanceof Map) {
			return ((Map<?, ?>)obj).isEmpty();
		} else if (obj instanceof List) {
			return ((List<?>)obj).isEmpty();
		} else if (obj instanceof Object[]) {
			return (((Object[])obj).length == 0);
		} else if (obj instanceof String) {
			return "".equals(((String)obj).trim());
		}

		return false;
	}

	/**
	 * 문자열이 숫자형태인지 여부를 반환
	 *
	 * @param str 문자열
	 * @return 문자열이 숫자형태인 경우 true
	 */
	public static boolean isNumber(String str) {

		if (isEmpty(str)) return false;

		if (str.matches("^[-+]?\\d+(\\.\\d+)?$")) {
			return true;
		} else {
			try {
				@SuppressWarnings("unused")
				double doubleVal = Double.parseDouble(str);
				return true;
			} catch (NumberFormatException de) {
				try {
					@SuppressWarnings("unused")
					BigDecimal bigDecimalVal = new BigDecimal(str);
					return true;
				} catch (NumberFormatException be) {
					return false;
				}
			}
		}
	}

	/**
	 * @param file
	 * @return 파일 내용
	 * @throws IOException
	 */
	public static String getFileContent(File file) throws IOException{
		List<String> stringPiece = Files.readAllLines(file.toPath());
		return String.join("\n", stringPiece);
	}

	/**
	 * 프로세스 실행
	 * @param runCmd
	 * @param pidPath
	 * @param queueSeq
	 * @return
	 * @throws Exception
	 */
	public static Process runProcess(Object runCmd, String pidPath) throws Exception {
		Process proc = null;

		// 실행
		if (runCmd instanceof String[])
			proc = Runtime.getRuntime().exec((String[])runCmd);
		else
			proc = Runtime.getRuntime().exec((String)runCmd);

		// PID 저장
		saveFile(pidPath, proc.pid());

		return proc;
	}

	/**
	 * 프로세스 종료
	 * @param queueSeq
	 * @throws Exception
	 */
	public static void killProcess(String taskkillCmd, String pidPath) throws Exception {
		File fPidPath = new File(pidPath);
		if (fPidPath.exists()) {
			String pid = SGKUtil.getFileContent(fPidPath);
			Runtime.getRuntime().exec(String.format(taskkillCmd, pid));
		}
	}

	/**
	 * Config 값 return
	 * @param key
	 * @return
	 * @throws Exception
	 */
	public static String getConfig(String key) throws Exception {
		return SGKJobLauncherRun.CONFIG.get(key);
	}

	/**
	 * Config 값 셋팅
	 * @param key
	 * @param val
	 * @throws Exception
	 */
	public static void setConfig(String key, String val) throws Exception {
		SGKJobLauncherRun.CONFIG.put(key, val);
	}
}
