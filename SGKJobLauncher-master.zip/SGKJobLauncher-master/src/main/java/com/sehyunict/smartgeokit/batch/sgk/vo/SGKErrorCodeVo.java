package com.sehyunict.smartgeokit.batch.sgk.vo;

public class SGKErrorCodeVo {
	
	private String errorCode;
	private String errorCodeName;
	private String jobStepMapping;
	
	public String getErrorCode() {
		return errorCode;
	}
	public String getErrorCodeName() {
		return errorCodeName;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public void setErrorCodeName(String errorCodeName) {
		this.errorCodeName = errorCodeName;
	}
	public String getJobStepMapping() {
		return jobStepMapping;
	}
	public void setJobStepMapping(String jobStepMapping) {
		this.jobStepMapping = jobStepMapping;
	}
}
