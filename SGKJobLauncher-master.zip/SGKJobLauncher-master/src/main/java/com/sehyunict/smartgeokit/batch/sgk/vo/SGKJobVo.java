package com.sehyunict.smartgeokit.batch.sgk.vo;

public class SGKJobVo {

	private String jobId; // 작업 식별 아이디
	private String jobName; // 작업명
	private String jobDesc; // 작업설명
	private int totalStepCount; // job 전체 step 수

	public String getJobId() {
		return jobId;
	}
	public void setJobId( String jobId ) {
		this.jobId = jobId;
	}
	public String getJobName() {
		return jobName;
	}
	public void setJobName( String jobName ) {
		this.jobName = jobName;
	}
	public String getJobDesc() {
		return jobDesc;
	}
	public void setJobDesc( String jobDesc ) {
		this.jobDesc = jobDesc;
	}
	public int getTotalStepCount() {
		return totalStepCount;
	}
	public void setTotalStepCount(int totalStepCount) {
		this.totalStepCount = totalStepCount;
	}

	@Override
	public String toString() {
		return "SGKJobVo [jobId=" + jobId + ", jobName=" + jobName + ", jobDesc=" + jobDesc + ", totalStepCount="
				+ totalStepCount + "]";
	}
}
