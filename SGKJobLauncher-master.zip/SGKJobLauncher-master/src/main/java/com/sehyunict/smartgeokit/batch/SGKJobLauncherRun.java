package com.sehyunict.smartgeokit.batch;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.PropertyResourceBundle;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sehyunict.smartgeokit.batch.sgk.util.SGKUtil;

public class SGKJobLauncherRun {

	private static final Logger logger = LogManager.getLogger(SGKJobLauncherRun.class);

	public static Map<String,String> CONFIG = new HashMap<String,String>();

	@SuppressWarnings( "unused" )
	public static void main(String[] args) throws Exception {
		if (args == null || args.length != 2) {
			logger.info("사용법을 확인하세요.");
			logger.info("사용법 : java -jar SGKJobLauncher.jar [서버명] [global.config Path]");
			System.exit(0);
		}

		// 실행 서버 설정
		CONFIG.put("TARGET_SERVER", args[0]);

		// global.config 파일 체크
		File globalConfig = new File(args[1]);
		if (!globalConfig.exists()) {
			logger.info("global.config 파일이 존재하지 않습니다.");
			System.exit(0);
		}

		// global.config를 읽어서 GlobalConfig에 셋팅
		PropertyResourceBundle prb = new PropertyResourceBundle(new FileInputStream(globalConfig));

		// global config path
		setGlobalConfig("GLOBAL_CONFIG_PATH", args[1]);
		// job launcher
		setGlobalConfig(prb, "SGKJL_ROOT_PATH");
		setGlobalConfig(prb, "DMS_DATA_PATH");
		setGlobalConfig(prb, "SGK_DATA_PATH");
		// autocad
		setGlobalConfig(prb, "ACAD_EXEC_FILE_PATH");
		setGlobalConfig(prb, "ACAD_EXEC_OPTS");
		setGlobalConfig(prb, "ACAD_EXEC_TIMEOUT_SECOND");
		setGlobalConfig(prb, "ACAD_LSP_FILE_PATH");
		setGlobalConfig(prb, "ACAD_HANDLER_USE_YN");
		// Autocad Handler 사용일 경우만 아래 config 체크
		if ("Y".equals(SGKUtil.getConfig("ACAD_HANDLER_USE_YN"))) {
			setGlobalConfig(prb, "ACAD_HANDLER_EXEC_CMD");
			setGlobalConfig(prb, "ACAD_HANDLER_SERVER_IP");
		}
		// bitcode
		setGlobalConfig(prb, "BITCODE_PARSER_FILE_PATH");
		// compare
		setGlobalConfig(prb, "FILE_DIFF_PATH");
		setGlobalConfig(prb, "COMPARE_EXE_PATH");
		setGlobalConfig(prb, "COMPARE_NODE_PATH");
		setGlobalConfig(prb, "FILE_WDFS_PATH");
		setGlobalConfig(prb, "FILE_BITCODE_PATH");
		setGlobalConfig(prb, "NODEJS_EXEC_OPTS");
		// etc
		setGlobalConfig(prb, "SSL_ZIP_EXEC_PATH");
		setGlobalConfig(prb, "TILE_GEN_FILE_PATH");

		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContext.xml");
	}

	private static void setGlobalConfig(PropertyResourceBundle prb, String key) {
		try {
			CONFIG.put(key, prb.getString(key));
		} catch (Exception e) {
			logger.info("[global.config] 필수 설정이 존재하지 않습니다. (" + key + ")");
			System.exit(0);
		}
	}
	
	private static void setGlobalConfig(String key, String value) {
		try {
			if(SGKUtil.isEmpty(key) || SGKUtil.isEmpty(value)) {
				throw new Exception();
			} else {
				CONFIG.put(key, value);
			}
		} catch (Exception e) {
			logger.info("[global.config] 수동 설정 Data가 존재하지 않습니다. (" + key + " / " + value + ")");
			System.exit(0);
		}
	}
}
