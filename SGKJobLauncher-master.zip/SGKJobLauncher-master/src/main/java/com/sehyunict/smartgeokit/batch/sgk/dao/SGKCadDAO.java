package com.sehyunict.smartgeokit.batch.sgk.dao;

import java.sql.SQLException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.ibatis.sqlmap.client.SqlMapClient;
import com.sehyunict.smartgeokit.batch.cad.vo.SGKCadDwgVo;
import com.sehyunict.smartgeokit.batch.cad.vo.SGKCadRevVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKCompareVo;
import com.sehyunict.smartgeokit.batch.sgk.vo.SGKJobParseVo;

@Repository
public class SGKCadDAO {

	@Autowired
	private SqlMapClient sqlManClient; 

	public SGKJobParseVo selectJobParseData(SGKJobParseVo sgkJobParseVo) throws SQLException {
		return (SGKJobParseVo)sqlManClient.queryForObject("cad.selectJobParseData", sgkJobParseVo);
	}

	public void updateCadRev(SGKCadRevVo revVo) throws SQLException {
		sqlManClient.insert("cad.updateCadRev", revVo);
	}

	public SGKCadDwgVo selectCadDwg(String dwgId) throws SQLException {
		return (SGKCadDwgVo)sqlManClient.queryForObject("cad.selectCadDwg", dwgId);
	}

	public void insertCompare(SGKCompareVo compareVo) throws SQLException {
		sqlManClient.insert("cad.insertCompare", compareVo);
	}
}