package com.sehyunict.smartgeokit.compare;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.sehyunict.smartgeokit.batch.sgk.util.SGKUtil;

public class CompareTest {

	String jobData = null;
	String arrJobData[] = new String[3];

	@Before
	public void setUp() throws Exception {
		jobData = "case^0^";
	}

	@Test
	public void validationTest() {

		// 구분자로 나눴을 경우 정상case 기준 length = 3, 도면명에 ^ 포함될경우 3 이상

		arrJobData[2] = jobData.substring(jobData.lastIndexOf("^") + 1);
		if(SGKUtil.isEmpty(arrJobData[2])) {
			System.out.println("[SGKCompare.execute] jobData : differ revision null - " + jobData);
		} else if(!SGKUtil.isNumber(arrJobData[2])) {
			System.out.println("[SGKCompare.execute] jobData : differ revision 이상 - " + jobData);
		}

		jobData = jobData.replace("^" + arrJobData[2], "");
		arrJobData[1] = jobData.substring(jobData.lastIndexOf("^") + 1);
		if(SGKUtil.isEmpty(arrJobData[1])) {
			System.out.println("[SGKCompare.execute] jobData : differ revision null - " + jobData);
		} else if(arrJobData[2].equals(arrJobData[1])) {
			System.out.println("[SGKCompare.execute] jobData : 동일한 revision 선택 - " + jobData);
		} else if(!SGKUtil.isNumber(arrJobData[1])) {
			System.out.println("[SGKCompare.execute] jobData : pivot revision 이상 - " + jobData);
		}

		jobData = jobData.replace("^" + arrJobData[1], "");
		arrJobData[0] = jobData;
		if(SGKUtil.isEmpty(arrJobData[0])) {
			System.out.println("[SGKCompare.execute] jobData : 도면명 이상 - " + jobData);
		}
	}

	@After
	public void tearDown() throws Exception {
		System.out.println("도면명 : " + arrJobData[0]);
		System.out.println("pivot revision : " + arrJobData[1]);
		System.out.println("differ revision : " + arrJobData[2]);
	}

}
